import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { TestComponent } from './test/test.component';
import { LoginComponent } from './login/login.component';
import { ShowempComponent } from './showemp/showemp.component';
import { ExperiencePipe } from './experience.pipe';
import { GenderPipe } from './gender.pipe';
import { ProductComponent } from './product/product.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';


const appRoot: Routes = [{path: '', component: LoginComponent},
{path: 'login', component: LoginComponent},
{path: 'employees', component: ShowempComponent},
{path: 'products', component: ProductComponent}];

@NgModule({
  declarations: [
    AppComponent,  // components
    TestComponent,
    LoginComponent, ShowempComponent, ExperiencePipe, GenderPipe, ProductComponent, HeaderComponent, FooterComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,    // modules
    RouterModule.forRoot(appRoot)
  ],
  providers: [],  // service
  bootstrap: [AppComponent]
})
export class AppModule { }
